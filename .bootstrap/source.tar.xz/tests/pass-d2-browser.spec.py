from __future__ import annotations
from pathlib import Path
from tempfile import TemporaryDirectory
import os, runpy, shutil, sys
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tests'))
base=runpy.run_path(str(ROOT/'tests/browser-qa.spec.py'),run_name='rd_d2_base')
HTML=(ROOT/'index.html').read_text().replace('<head>','<head>'+base['INDEXEDDB_SHIM'],1)
FIXTURE=ROOT/'tests/fixtures/browser-baseline.rdbackup'
checks=0

def check(v,m):
    global checks; checks+=1
    if not v: raise AssertionError(m)

def wait(page,ms=400): page.wait_for_timeout(ms)

def restore_selected(page, tmp:Path, treatment:str='discard'):
    check(page.locator('#restore-dialog').is_visible(),'Restore preview did not open')
    with page.expect_download() as info:
        page.locator('[data-action="create-restore-safety"]').click()
    dl=info.value; safety=tmp/dl.suggested_filename; dl.save_as(str(safety))
    check(safety.exists() and safety.stat().st_size>0,'Safety copy was not downloaded')
    check(safety.suffix in ('.rdbackup','.rdrescue'),'Safety copy extension is invalid')
    if page.locator('input[name="restore-active-treatment"]').count():
        page.locator(f'input[name="restore-active-treatment"][value="{treatment}"]').check()
    page.locator('#restore-safety-saved').check()
    page.locator('#restore-replace-confirm').check()
    check(page.locator('#restore-final-button').is_enabled(),'Final restore remained disabled')
    page.locator('#restore-final-button').click(); wait(page,1200)

def main():
    global checks
    exe=os.environ.get('CHROMIUM_EXECUTABLE') or shutil.which('chromium') or shutil.which('chromium-browser') or shutil.which('google-chrome')
    with sync_playwright() as pw, TemporaryDirectory() as td:
        tmp=Path(td)
        browser=pw.chromium.launch(headless=True,executable_path=exe if exe else None,args=['--no-sandbox','--disable-dev-shm-usage'])
        page=browser.new_page(viewport={'width':1440,'height':1000})
        errors=[]
        page.on('pageerror',lambda e:errors.append(str(e)))
        page.on('console',lambda m:errors.append(m.text) if m.type=='error' else None)
        page.on('dialog',lambda d:d.accept())
        page.set_content(HTML,wait_until='load');wait(page,1300)
        check(not page.locator('#fatal-error').is_visible(),'Fatal startup error')
        page.locator('[data-pane="settings"]').click();wait(page)
        before=page.locator('#sb-units').inner_text()
        page.locator('#import-backup').set_input_files(str(FIXTURE));wait(page,900)
        check(page.locator('#restore-preview').get_by_text('No application data has been changed').count()==1,'Non-mutating inspection message missing')
        check(page.locator('#sb-units').inner_text()==before,'Inspection mutated application state')
        check('Archive checksum:' in page.locator('#restore-preview').inner_text(),'Restore preview lacks checksum')
        restore_selected(page,tmp,'discard')
        check(page.locator('#sb-units').inner_text()=='2','Verified restore did not replace records')
        check('verified backup restored' in page.locator('#toast').inner_text().lower(),'Restore success not reported')
        # One-click local export remains simple.
        page.locator('[data-pane="settings"]').click();wait(page)
        with page.expect_download() as info:
            page.locator('[data-action="export-backup"]').click()
        exported=tmp/info.value.suggested_filename;info.value.save_as(str(exported))
        check(exported.suffix=='.rdbackup' and exported.stat().st_size>0,'One-click export failed')
        # Start an unfinished retrieval and export it.
        page.locator('[data-pane="today"]').click();wait(page)
        page.locator('[data-action="start-due"]').click();wait(page,700)
        attempt=page.locator('#attempt-text')
        if attempt.count(): attempt.fill('Durable active retrieval text')
        page.locator('[data-pane="settings"]').click();wait(page)
        with page.expect_download() as active_info:
            page.locator('[data-action="export-backup"]').click()
        active_file=tmp/active_info.value.suggested_filename;active_info.value.save_as(str(active_file))
        # Reinspect active backup: preview must require explicit treatment.
        page.locator('#import-backup').set_input_files(str(active_file));wait(page,900)
        check(page.locator('input[name="restore-active-treatment"]').count()==2,'Active-session treatment choices missing')
        check(page.locator('#restore-final-button').is_disabled(),'Restore enabled before active-session treatment')
        restore_selected(page,tmp,'restore')
        check(page.locator('#pane-review').is_visible(),'Restored unfinished retrieval did not hydrate Review')
        restored=page.locator('#attempt-text')
        if restored.count(): check(restored.input_value()=='Durable active retrieval text','Restored active draft was lost')
        # Selecting a tampered file must not enter restore ceremony.
        data=bytearray(FIXTURE.read_bytes()); data[-10]^=1
        tampered=tmp/'tampered.rdbackup';tampered.write_bytes(data)
        page.locator('[data-pane="settings"]').click();wait(page)
        page.locator('#import-backup').set_input_files(str(tampered));wait(page,700)
        msg=page.locator('#toast').inner_text().lower()
        check('checksum' in msg or 'integrity' in msg or 'json' in msg,'Tampered backup was not rejected')
        check(not errors,f'Browser errors: {errors}')
        browser.close()
    print(f'PASS {checks} Pass D2 browser restore-controller checks')

if __name__=='__main__': main()
